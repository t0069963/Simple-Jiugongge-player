import minimu


minimu.wakeup()
