#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from setuptools import setup


setup(
    name='minimu',
    version='0.1',
    packages=['minimu']
)
